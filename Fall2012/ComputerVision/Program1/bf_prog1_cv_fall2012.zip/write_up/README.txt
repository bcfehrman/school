
To make a sample CVPR paper, copy the contents of this directory
somewhere, and type

 pdflatex egpaper_final
