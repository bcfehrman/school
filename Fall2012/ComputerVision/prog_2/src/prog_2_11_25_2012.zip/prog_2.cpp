/////////////////////////
// Author: Brian Fehrman
// Unity file for Computer Vision Fall 2012 Program 2
////////////////////////

#include "prog_2_main.cpp"
#include "manual_stitch.cpp"
#include "stitcher.cpp"
#include "stitch_menu.cpp"
#include "auto_stitch.cpp"
