///////////////////////
//Author: Brian Fehrman
//Include file for F2012 pattern recognition prog 1
/////////////////////

#ifndef _PROG_1_H
#define _PROG_1_H

#include<iostream>
#include<stdlib.h>
#include "mahalanobis_classifier.h"
#include "mle_classifier.h"
#include "knn_classifier.h"

using namespace std;

#endif
