%%% 5-14-2011

%%% Data for iterative time reversal tests using two solid steel rod
%%% segments of slightly different length and three transducers. One
%%% transducer acts as the defect and is compressed between the two rods.
%%% The other two transducers are placed on the open ends of the rods. The
%%% system in then compressed as a whole. One of the end transducers (Ch0) sends
%%% an initial multi-toned pulse. All three transducers record 1000 samples.
%%% The first instance of the reflection pulse is extracted from the 1000
%%% samples read in by Ch0. This pulse is rescaled and delays are put into
%%% place based upon where the pulse was found in the larger signal. This
%%% new signal (pulses with time delays between them) is then replayed by Ch0.
%%% 1000 samples are read by all three transducers again. Both the defect 
%%% transducer and Ch1 (the opposite end transducer) were used only for reading
%%% in these tests and did not play back any signals. It should also be noted that the
%%% beginning of the signals plotted for Ch0 and Ch1 are "zeroed out" to get rid of the portion
%%% where the initial wave is being played out by Ch0 since it is assumed that the distance
%%% between the transducers is greater than the length of the initial wave.

%%% The idea is that the waves played out by Ch0, with the time delays between them,
%%% will combine with each other to create a wave of greater amplitude. This happens because
%%% the reflection of the previous wave will reach Ch0 as it is playing out the next wave
%%% due to the correct time delays that are inserted between the waves (thanks to the
%%% time reversal algorithm).

%%% This seems to work fine for the first combining of the waves (as shown in the final
%%% figures that plot the subsets of the data). Seems to not work as well after that.
%%% A few corrections were made to the program that had generated the previous results.
%%% Will attempt this test using a single rod segment and compare the results.

close all
clear all

multi_toned_pulse = load('multi_toned_pulse.lvm');

defect_initial_phase = load('defect_initial.lvm');
ch0_initial_phase = load('ch0_initial.lvm');
ch1_initial_phase = load('ch1_initial.lvm');

defect_tr_phase = load('defect_second.lvm');
ch0_resent_wave = load('ch0_resent.lvm');
ch1_tr_phase = load('ch1_second.lvm');

t_step = 54/40000000;  %The sampling speed for these tests (based on 40MHz FPGA clock ticks)

t_signals = 0:t_step:(t_step * length(defect_initial_phase) - t_step);
t_pulse = 0:t_step:(t_step * length(multi_toned_pulse) - t_step);

figure(1)
plot(t_pulse, multi_toned_pulse)
xlabel('Time (Seconds)')
ylabel('Multi-toned pulse (Volts)')
title('Multi-toned pulse sent by Ch0 during initial phase')

figure(2)
plot(t_signals, ch0_initial_phase)
xlabel('Time (Seconds)')
ylabel('Ch0 Response (Volts)')
title('Response at Ch0 (sending transducer) during initial phase')


figure(3)
plot(t_signals, defect_initial_phase)
xlabel('Time (Seconds)')
ylabel('Defect response (Volts)')
title('Response at Defect Transducer During Initial Phase')

figure(4)
plot(t_signals, ch1_initial_phase)
xlabel('Time (Seconds)')
ylabel('Ch1 Response (Volts)')
title('Response at Ch1 (opposite end transducer, not utilized in this test for anything other than reading) during initial phase')

t_resent = 0:t_step:(t_step * length(ch0_resent_wave) - t_step);

figure(5)
plot(t_resent,ch0_resent_wave)
xlabel('Time (Seconds)')
ylabel('Resent Wave (Volts)')
title('Wave that is resent by ch0 (With time delays)')

figure(6)
plot(t_signals, defect_tr_phase)
xlabel('Time (Seconds)')
ylabel('Defect Response (Volts)')
title('Response at defect during time reversal phase')

figure(7)
plot(t_signals, ch1_tr_phase)
xlabel('Time (Seconds)')
ylabel('Ch1 Response (Volts)')
title('Response at Ch1 during time reversal phase')

sub_length = 400;

defect_init_sub = defect_initial_phase(1:sub_length);
defect_tr_sub = defect_tr_phase(1:sub_length);
ch1_init_sub = ch1_initial_phase(1:sub_length);
ch1_tr_sub = ch1_tr_phase(1:sub_length);

t_sub = 0:t_step:(sub_length*t_step - t_step);

figure(8)
plot(t_sub, defect_init_sub)
xlabel('Time (Seconds)')
ylabel('Defect Response (Volts)')
title('Zoom in of response at Defect during initial phase')

figure(9)
plot(t_sub, defect_tr_sub)
xlabel('Time (Seconds)')
ylabel('Defect Response (Volts)')
title('Zoom in of response at Defect during time reversal phase')


figure(10)
plot(t_sub, defect_init_sub, t_sub, defect_tr_sub)
xlabel('Time (Seconds)')
ylabel('Defect Response (Volts)')
title('Zoomed in Overlay of Defect response during initial and TR phase')
legend('Defect Initial Phase', 'Defect TR Phase')

figure(11)
plot(t_sub, ch1_init_sub)
xlabel('Time (Seconds)')
ylabel('Ch1 Response (Volts)')
title('Zoom in of response at Ch1 during initial phase')

figure(12)
plot(t_sub, ch1_tr_sub)
xlabel('Time (Seconds)')
ylabel('Ch1 Response (Volts)')
title('Zoom in of response at Ch1 during time reversal phase')


figure(13)
plot(t_sub, ch1_init_sub, t_sub, ch1_tr_sub)
xlabel('Time (Seconds)')
ylabel('Ch1 Response (Volts)')
title('Zoomed in Overlay of Ch1 response during initial and TR phase')
legend('Ch1 Initial Phase', 'Ch1 TR Phase')
